package_version = '1.0.0'
package_name = 'junos_common_operations'
